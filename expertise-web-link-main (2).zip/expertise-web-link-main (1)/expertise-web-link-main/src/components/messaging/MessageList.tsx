import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, User, Clock, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { UserSearch } from './UserSearch';
import { TypingIndicator } from './TypingIndicator';

interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  created_at: string;
  read_at: string | null;
  sender_profile?: {
    display_name: string | null;
  };
  recipient_profile?: {
    display_name: string | null;
  };
}

interface MessageListProps {
  selectedUserId?: string;
  onSelectUser?: (userId: string, displayName: string) => void;
  typingUsers?: Set<string>;
}

export function MessageList({ selectedUserId, onSelectUser, typingUsers = new Set() }: MessageListProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showUserSearch, setShowUserSearch] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchConversations = async () => {
    if (!user) return;

    try {
      // Get unique conversations
      const { data: messagesData, error } = await supabase
        .from('messages')
        .select('*')
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      // Get profiles separately
      const userIds = messagesData?.map(m => [m.sender_id, m.recipient_id]).flat() || [];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, display_name')
        .in('user_id', [...new Set(userIds)]);

      if (error) throw error;

      // Group by conversation partner
      const conversationMap = new Map();
      
      messagesData?.forEach((message) => {
        const isFromMe = message.sender_id === user.id;
        const partnerId = isFromMe ? message.recipient_id : message.sender_id;
        const partnerProfile = profiles?.find(p => p.user_id === partnerId);
        const partnerName = partnerProfile?.display_name;

        if (!conversationMap.has(partnerId)) {
          conversationMap.set(partnerId, {
            partnerId,
            partnerName: partnerName || 'Anonymous User',
            lastMessage: message,
            unreadCount: 0
          });
        }

        // Count unread messages from partner
        if (!isFromMe && !message.read_at) {
          conversationMap.get(partnerId).unreadCount++;
        }
      });

      setConversations(Array.from(conversationMap.values()));
    } catch (error) {
      console.error('Error fetching conversations:', error);
      toast({
        title: "Error",
        description: "Failed to load conversations",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMessages = async () => {
    if (!user || !selectedUserId) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(`and(sender_id.eq.${user.id},recipient_id.eq.${selectedUserId}),and(sender_id.eq.${selectedUserId},recipient_id.eq.${user.id})`)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setMessages(data || []);

      // Mark messages as read
      await supabase
        .from('messages')
        .update({ read_at: new Date().toISOString() })
        .eq('sender_id', selectedUserId)
        .eq('recipient_id', user.id)
        .is('read_at', null);

    } catch (error) {
      console.error('Error fetching messages:', error);
      toast({
        title: "Error",
        description: "Failed to load messages",
        variant: "destructive"
      });
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (selectedUserId) {
      scrollToBottom();
    }
  }, [messages, selectedUserId]);

  useEffect(() => {
    fetchConversations();

    // Set up real-time subscription
    const channel = supabase
      .channel('messages_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages'
        },
        () => {
          fetchConversations();
          if (selectedUserId) {
            fetchMessages();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  useEffect(() => {
    if (selectedUserId) {
      fetchMessages();
    }
  }, [selectedUserId, user]);

  if (!selectedUserId) {
    return (
      <>
        <Card className="glass-effect neon-border terminal-glow">
          <CardHeader>
            <CardTitle className="neon-text font-orbitron flex items-center justify-between terminal-text">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                CONVERSATIONS_SYS
              </div>
              <Button
                onClick={() => setShowUserSearch(true)}
                className="glow-green hover:glow-pink transition-all duration-300"
                size="sm"
              >
                <Plus className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">New Chat</span>
              </Button>
            </CardTitle>
          </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="terminal-text">[LOADING_CONVERSATIONS...]</div>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary ml-4"></div>
            </div>
          ) : conversations.length === 0 ? (
            <p className="terminal-text text-center py-8">
              {'{> NO_ACTIVE_CONNECTIONS}'}
              <br />
              {'{> INITIATE_SKILL_EXCHANGE_TO_BEGIN}'}
            </p>
          ) : (
            <div className="space-y-3">
              {conversations.map((conversation) => (
                <motion.div
                  key={conversation.partnerId}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    variant="ghost"
                    className="w-full justify-start h-auto p-4 glass-effect terminal-glow hover:glow-green transition-all duration-300"
                    onClick={() => onSelectUser?.(conversation.partnerId, conversation.partnerName)}
                  >
                    <div className="flex items-center gap-3 w-full">
                      <User className="h-10 w-10 p-2 bg-primary/20 rounded-full text-primary" />
                      <div className="flex-1 text-left">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium terminal-text">[USER] {conversation.partnerName}</h4>
                          {conversation.unreadCount > 0 && (
                            <span className="bg-primary text-primary-foreground rounded-full px-2 py-1 text-xs">
                              {conversation.unreadCount}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground truncate terminal-text">
                          {'{>'} {conversation.lastMessage?.content}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(conversation.lastMessage?.created_at))} ago
                        </p>
                      </div>
                    </div>
                  </Button>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      <AnimatePresence>
        {showUserSearch && (
          <UserSearch
            onSelectUser={(userId, displayName) => {
              onSelectUser?.(userId, displayName);
              setShowUserSearch(false);
            }}
            onClose={() => setShowUserSearch(false)}
          />
        )}
      </AnimatePresence>
      </>
    );
  }

  return (
    <Card className="glass-effect neon-border h-[50vh] sm:h-[60vh] lg:h-[600px] flex flex-col terminal-glow">
      <CardHeader className="pb-2 sm:pb-4">
        <CardTitle className="neon-text font-orbitron flex items-center gap-2 terminal-text text-sm sm:text-base">
          <MessageCircle className="h-4 w-4 sm:h-5 sm:w-5" />
          MESSAGE_STREAM
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto px-2 sm:px-6">
        <div className="space-y-2 sm:space-y-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[70%] p-3 rounded-lg glass-effect text-sm sm:text-base ${
                  message.sender_id === user?.id
                    ? 'bg-primary/20 neon-border glow-pulse'
                    : 'bg-secondary/50 terminal-glow'
                }`}
              >
                <p className="break-words terminal-text">{message.content}</p>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {formatDistanceToNow(new Date(message.created_at))} ago
                </div>
              </div>
            </motion.div>
          ))}
          
          {/* Typing indicator */}
          <AnimatePresence>
            {typingUsers.has(selectedUserId || '') && (
              <TypingIndicator userName="User" />
            )}
          </AnimatePresence>
          
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
    </Card>
  );
}